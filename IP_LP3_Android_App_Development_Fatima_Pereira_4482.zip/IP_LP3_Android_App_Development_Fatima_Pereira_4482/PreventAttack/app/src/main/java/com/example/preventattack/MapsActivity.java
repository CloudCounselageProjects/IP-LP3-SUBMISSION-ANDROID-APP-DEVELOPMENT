package com.example.preventattack;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.telephony.SmsManager;

public class MapsActivity extends AppCompatActivity {
    private TextView logView;
    private ImageView imageView;
    Button btnOK;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acticity_maps);


        logView = findViewById(R.id.log);
        logView.setText("\nPanic Alert Activated...\n");
        imageView = findViewById(R.id.resultImage);
        btnOK = findViewById(R.id.btnOK);
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        logView.append("Checking SMS and location App permissions...\n");
        if (ActivityCompat.checkSelfPermission(MapsActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MapsActivity.this,
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MapsActivity.this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            logView.append("--->Valid!\n");
            getCurrentLocation();
        } else {
            logView.append("--->Invalid!\n");
            exit(-1);
        }

        if(HomeActivity.fusedLocationProviderClient == null)
            HomeActivity.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        HomeActivity.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
    }

    void exit(int exitCode) {
        switch (exitCode) {
            case 0: // Process successful
                logView.setText(logView.getText().toString() + "Exiting...\n");
                logView.setText(logView.getText().toString() + "END\n");
                imageView.setImageResource(R.mipmap.correct);
                setResult(RESULT_OK);
                btnOK.setVisibility(View.VISIBLE);
                break;
            case -1:
                logView.setText(logView.getText().toString() + "ERROR...\n");
                logView.setText(logView.getText().toString() + "Could not send location! Please try again!\n");
                logView.setText(logView.getText().toString() + "Terminating...\n");
                logView.setText(logView.getText().toString() + "END\n");
                imageView.setImageResource(R.mipmap.unsuccess);
                setResult(RESULT_CANCELED);
                btnOK.setVisibility(View.VISIBLE);
        }
    }

    private void sendSMS(Location location) {

        if(ActivityCompat.checkSelfPermission(getApplicationContext(),Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                logView.append("Sending the location co-ordinates through SMS...\n");
                String phoneNumber = new DatabaseHelper(getApplicationContext()).getEmergencyPhone();
                String message = getResources().getString(R.string.message)+"http://maps.google.com/?q=" + location.getLatitude() + "," + location.getLongitude();
                SmsManager smsManager = SmsManager.getDefault();
                System.out.println("Sending sms to "+phoneNumber);
                smsManager.sendTextMessage(phoneNumber.trim(), null, message, null, null);
                //TODO: replace the toast with an updated text view in the home activity with a message saying location sent successfully
                // Update the text view at every step of the process
                logView.append("--->SMS sent successfully...\n");
                exit(0);
            } catch (SecurityException e) {
                e.printStackTrace();
                logView.append("--->ERROR...Could not send SMS\n");
                exit(-1);
            }
        }else{
            logView.append("--->SMS Permission not granted...\n");
            exit(-1);
        }
    }

    @SuppressLint("MissingPermission")
    private void getCurrentLocation() {

        LocationManager locationManager = (LocationManager) getSystemService(
                Context.LOCATION_SERVICE);

        logView.append("Checking if location access is enabled...\n");

        if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){

            logView.append("--->Enabled!\n");

            if(HomeActivity.fusedLocationProviderClient!=null) {
                HomeActivity.fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {

                        logView.append("Finding location co-ordinates...\n");

                        final Location location = task.getResult();
                        if (location != null) {
                            logView.append("Found co-ordinates as:\n" + "Latitude: " + location.getLatitude() + "\n" + "Longitude: " + location.getLongitude() + "\n");
                            sendSMS(location);
                        } else {
                            LocationRequest locationRequest = LocationRequest.create()
                                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                                    .setInterval(10000)
                                    .setFastestInterval(1000)
                                    .setNumUpdates(1);

                            LocationCallback locationCallback = new LocationCallback() {
                                @Override
                                public void onLocationResult(@NonNull LocationResult locationResult) {
                                    Location location1 = locationResult.getLastLocation();
                                    sendSMS(location1);
                                }
                            };

                            HomeActivity.fusedLocationProviderClient.requestLocationUpdates(locationRequest,
                                    locationCallback, Looper.myLooper());
                        }
                    }
                });
            }else{
                HomeActivity.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
            }
        }else{
            logView.append("--->ERROR!\n");
            exit(-1);
        }
    }
}
