package com.example.preventattack;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.internal.BaseGmsClient;
import com.google.android.gms.common.internal.Objects;
import com.google.android.material.textview.MaterialTextView;

public class Settings extends AppCompatActivity {

    private EditText detailsEditText, oldPinEditText, newPinEditText, newRePinEditText;
    private Spinner spinner;
    private MaterialTextView txtOldValue;
    private int spinnerSelection;
    Button btnChangeDetails, btnChangePassword;
    private boolean validOldPin, validNewPin, validNewRePin;
    private static DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        initializeSettings();
        settingsMethod();

        if(helper == null){
            helper = new DatabaseHelper(getApplicationContext());
        }

        validOldPin = validNewPin = validNewRePin = false;
    }

    private void initializeSettings(){
        detailsEditText = findViewById(R.id.personalDetailsEditText);
        oldPinEditText = findViewById(R.id.editTxtOldPin);
        newPinEditText = findViewById(R.id.editTxtNewPin);
        newRePinEditText = findViewById(R.id.editTxtNewRePin);
        btnChangeDetails = findViewById(R.id.btnSavePersonalDetails);
        btnChangePassword = findViewById(R.id.btnSavePinDetails);
        txtOldValue = findViewById(R.id.showOldValueTextView);
        spinner = findViewById(R.id.personalDetailsSpinner);

        spinner.requestFocus();

    }

    private void settingsMethod(){

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                detailsEditText.getText().clear();
                switch(position){
                    case 0:
                        spinnerSelection = 0;
                        txtOldValue.setText(getOldValue(spinnerSelection));
                        detailsEditText.setInputType(InputType.TYPE_CLASS_TEXT);
                        Toast.makeText(getApplicationContext(),"FIRST NAME SELECTED",Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        spinnerSelection = 1;
                        txtOldValue.setText(getOldValue(spinnerSelection));
                        Toast.makeText(getApplicationContext(),"LAST NAME SELECTED",Toast.LENGTH_SHORT).show();
                        detailsEditText.setInputType(InputType.TYPE_CLASS_TEXT);
                        break;
                    case 2:
                        spinnerSelection = 2;
                        txtOldValue.setText(getOldValue(spinnerSelection));
                        Toast.makeText(getApplicationContext(),"EMAIL ADDRESS SELECTED",Toast.LENGTH_SHORT).show();
                        detailsEditText.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
                        break;
                }
                detailsEditText.requestFocus();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        detailsEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                switch(detailsEditText.getInputType()){
                    case InputType.TYPE_CLASS_TEXT:
                        if (s.toString().matches("[A-Za-z]+")) {
                            //validName = true;
                            btnChangeDetails.setEnabled(true);
                            detailsEditText.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            //validFirstName = false;
                            btnChangeDetails.setEnabled(false);
                            detailsEditText.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                        break;
                    case InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS:
                        if (s.toString().matches("^[A-Za-z0-9][A-Za-z0-9.+_-]+@[A-Za-z]+[.][A-Za-z][A-Za-z.]+[A-Za-z]$")) {
                            //validEmergencyEmailID = true;
                            detailsEditText.setTextColor(getResources().getColor(R.color.darkGreen));
                            btnChangeDetails.setEnabled(true);
                        } else {
                            //validEmergencyEmailID = false;
                            detailsEditText.setTextColor(getResources().getColor(R.color.cherryRed));
                            btnChangeDetails.setEnabled(false);
                        }
                        break;
                }
            }
        });

        btnChangeDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch(detailsEditText.getInputType()){

                    case InputType.TYPE_CLASS_TEXT:
                        switch(spinnerSelection){
                            case 0: //change first name
                                if(helper.changeDetails("first_name",detailsEditText.getText().toString())){
                                    Toast.makeText(getApplicationContext(),"UPDATE SUCCESSFUL",Toast.LENGTH_SHORT).show();
                                    txtOldValue.setText(getOldValue(spinnerSelection));
                                }
                                else{
                                    Toast.makeText(getApplicationContext(),"ERROR! TRY AGAIN",Toast.LENGTH_SHORT).show();
                                }
                                break;
                            case 1: //change last name
                                if(helper.changeDetails("last_name",detailsEditText.getText().toString())){
                                    Toast.makeText(getApplicationContext(),"UPDATE SUCCESSFUL",Toast.LENGTH_SHORT).show();
                                    txtOldValue.setText(getOldValue(spinnerSelection));
                                }
                                else{
                                    Toast.makeText(getApplicationContext(),"ERROR! TRY AGAIN",Toast.LENGTH_SHORT).show();
                                }
                                break;
                        }
                        break;
                    case InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS:
                        if(helper.changeDetails("email_address",detailsEditText.getText().toString())){
                            Toast.makeText(getApplicationContext(),"UPDATE SUCCESSFUL",Toast.LENGTH_SHORT).show();
                            txtOldValue.setText(getOldValue(2));
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"ERROR! TRY AGAIN",Toast.LENGTH_SHORT).show();
                        }
                }
                detailsEditText.getText().clear();
            }
        });

        oldPinEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 4) {
                    validOldPin = true;
                    oldPinEditText.setTextColor(getResources().getColor(R.color.navyBlue));
                    newPinEditText.requestFocus();
                } else {
                    validOldPin = false;
                    newPinEditText.getText().clear();
                    newRePinEditText.getText().clear();
                    oldPinEditText.setTextColor(getResources().getColor(R.color.navyBlue));
                }
                checkPinDetails();
            }
        });

        newPinEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (oldPinEditText.getText().length() != 4) {
                    newPinEditText.getText().clear();
                    newRePinEditText.getText().clear();
                    oldPinEditText.requestFocus();
                }
                else if(s.length() == 4){
                    validNewPin = true;
                    newPinEditText.setTextColor(getResources().getColor(R.color.darkGreen));
                    newRePinEditText.requestFocus();
                }
                else {
                    validNewRePin = false;
                    newRePinEditText.getText().clear();
                    newPinEditText.setTextColor(getResources().getColor(R.color.cherryRed));
                }
                checkPinDetails();
            }
        });

        newRePinEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (oldPinEditText.getText().length() != 4) {
                    newPinEditText.getText().clear();
                    newRePinEditText.getText().clear();
                    oldPinEditText.requestFocus();
                }
                else if(newPinEditText.getText().length()!=4){
                    newRePinEditText.getText().clear();
                    newPinEditText.requestFocus();
                }
                else if (s.length() == 4 & newPinEditText.getText().toString().equals(s.toString())) {
                    validNewRePin = true;
                    newRePinEditText.setTextColor(getResources().getColor(R.color.darkGreen));
                } else {
                    validNewRePin = false;
                    newRePinEditText.setTextColor(getResources().getColor(R.color.cherryRed));
                }
                checkPinDetails();
            }
        });

        btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(helper.verifyPassword(oldPinEditText.getText().toString())){
                    Toast.makeText(getApplicationContext(), "PASSWORD UPDATED", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "INCORRECT PASSWORD! TRY AGAIN", Toast.LENGTH_SHORT).show();
                }
                oldPinEditText.getText().clear();
                newPinEditText.getText().clear();
                newRePinEditText.getText().clear();
            }
        });
    }

    private String getOldValue(int spinnerSelected){
        switch(spinnerSelected){
            case 0:
                return helper.getCurrentValue("first_name").toUpperCase();
            case 1:
                return helper.getCurrentValue("last_name").toUpperCase();
            case 2:
                return helper.getCurrentValue("email_address");
        }
        return "";
    }

    private void checkPinDetails(){
        if(validOldPin & validNewPin & validNewRePin)
            btnChangePassword.setEnabled(true);
        else
            btnChangePassword.setEnabled(false);
    }

}