package com.example.preventattack;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    private EditText firstName, lastName, emailID, emergencyPhone, emergencyEmailID, pin, rePin;
    private Button btnRegister;
    private static boolean isSuccess;
    private static boolean validFirstName,
            validLastName,
            validEmail,
            validEmergencyPhone,
            validEmergencyEmailID,
            validPin;
    private static DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        isSuccess = false;
        validFirstName = false;
        validLastName = false;
        validEmail = false;
        validEmergencyPhone = false;
        validEmergencyEmailID = false;
        validPin = false;

        if(helper==null) {
            helper = new DatabaseHelper(getApplicationContext());
        }

        initializeRegistration();
        registrationMethod();
    }

    private void initializeRegistration(){
        firstName = findViewById(R.id.firstName);
        lastName = findViewById(R.id.lastName);
        emailID = findViewById(R.id.email);
        pin = findViewById(R.id.pin);
        rePin = findViewById(R.id.rePin);
        emergencyPhone = findViewById(R.id.emergencyPhone);
        emergencyEmailID = findViewById(R.id.emergencyEmail);
        btnRegister = findViewById(R.id.btnRegister);

        firstName.requestFocus();
    }

    private void registrationMethod(){
        firstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(final Editable s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (s.toString().matches("[A-Za-z]+")) {
                            validFirstName = true;
                            checkRegistrationDetails();
                            firstName.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            validFirstName = false;
                            checkRegistrationDetails();
                            firstName.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                    }
                });
            }
        });

        lastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(final Editable s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (s.toString().matches("[A-Za-z]+")) {
                            validLastName = true;
                            checkRegistrationDetails();
                            lastName.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            validLastName = false;
                            checkRegistrationDetails();
                            lastName.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                    }
                });
            }
        });

        emailID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(final Editable s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (s.toString().matches("^[A-Za-z0-9][A-Za-z0-9.+_-]+@[A-Za-z]+[.][A-Za-z][A-Za-z.]+[A-Za-z]$")) {
                            validEmail = true;
                            checkRegistrationDetails();
                            emailID.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            validEmail = false;
                            checkRegistrationDetails();
                            emailID.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                    }
                });
            }
        });

        pin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(final Editable s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (s.length() == 4) {
                            validPin = true;
                            pin.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            validPin = false;
                            rePin.getText().clear();
                            pin.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                        checkRegistrationDetails();
                    }
                });
            }
        });

        rePin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(final Editable s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (pin.getText().length() != 4) {
                            rePin.getText().clear();
                            pin.requestFocus();
                        } else if (s.length() == 4 & pin.getText().toString().equals(s.toString())) {
                            validPin = true;
                            rePin.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            validPin = false;
                            rePin.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                        checkRegistrationDetails();
                    }
                });
            }
        });

        emergencyPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(final Editable s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (s.toString().matches("[0-9]{10}")) {
                            validEmergencyPhone = true;
                            emergencyPhone.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            validEmergencyPhone = false;
                            emergencyPhone.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                        checkRegistrationDetails();
                    }
                });
            }
        });

        emergencyEmailID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(final Editable s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (s.toString().matches("^[A-Za-z0-9][A-Za-z0-9.+_-]+@[A-Za-z]+[.][A-Za-z][A-Za-z.]+[A-Za-z]$")) {
                            validEmergencyEmailID = true;
                            emergencyEmailID.setTextColor(getResources().getColor(R.color.darkGreen));
                        } else {
                            validEmergencyEmailID = false;
                            emergencyEmailID.setTextColor(getResources().getColor(R.color.cherryRed));
                        }
                        checkRegistrationDetails();
                    }
                });
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        if (helper.didUserRegister()) {
                            Toast.makeText(getApplicationContext(), "ALREADY REGISTERED!", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            UserDetails user = new UserDetails(
                                    firstName.getText().toString().toLowerCase(),
                                    lastName.getText().toString().toLowerCase(),
                                    emailID.getText().toString(),
                                    emergencyPhone.getText().toString(),
                                    emergencyEmailID.getText().toString(),
                                    MD5.getHashedPassword(pin.getText().toString()));

                            isSuccess = helper.registerUser(user);
                            if (isSuccess) {
                                Intent intent = new Intent();
                                intent.setClass(getApplicationContext(),HomeActivity.class);
                                startActivity(intent);
                                finish();

                                Toast.makeText(getApplicationContext(), "✓ REGISTRATION SUCCESSFUL", Toast.LENGTH_SHORT).show();
                            } else
                                Toast.makeText(getApplicationContext(), "✖ ERROR!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    private synchronized void checkRegistrationDetails(){

        if(validFirstName & validLastName & validEmail & validPin & validEmergencyPhone & validEmergencyEmailID){
            btnRegister.setEnabled(true);
        }else{
            btnRegister.setEnabled(false);
        }
    }

}