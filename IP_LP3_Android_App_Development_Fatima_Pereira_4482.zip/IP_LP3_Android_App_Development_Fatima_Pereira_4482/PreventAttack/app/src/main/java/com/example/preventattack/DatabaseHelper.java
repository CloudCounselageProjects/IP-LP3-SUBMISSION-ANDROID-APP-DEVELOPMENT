package com.example.preventattack;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.Map;
import java.util.HashMap;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String USER_INFO_TABLE = "user_info";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_FIRST_NAME = "first_name";
    public static final String COLUMN_LAST_NAME = "last_name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_EMERGENCY_PHONE = "emergency_phone";
    public static final String COLUMN_EMERGENCY_EMAIL = "emergency_email";
    public static final String COLUMN_PIN = "pin";
    public static final String TABLE_SALT = "TABLE_SALT";
    public static final String COLUMN_SALT = "salt";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "user.db", null, 1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    @Override
    public void onCreate(final SQLiteDatabase db) {

        String createUserTableQuery = "CREATE TABLE " + USER_INFO_TABLE + "(" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_FIRST_NAME + " TEXT," +
                COLUMN_LAST_NAME + " TEXT," +
                COLUMN_EMAIL + " TEXT," +
                COLUMN_PIN + " TEXT," +
                COLUMN_EMERGENCY_PHONE + " TEXT," +
                COLUMN_EMERGENCY_EMAIL + " TEXT)";

        db.execSQL(createUserTableQuery);
    }

    public boolean unRegister(){
        boolean result = false;
        SQLiteDatabase db = this.getWritableDatabase();
        int isSuccess = db.delete(USER_INFO_TABLE,"1",null);
        if(isSuccess!=0){
            System.out.println("User deleted");
            result = true;
        }else{
            System.out.println("Error deleting");
            result = false;
        }
        return result;
    }

    public String getCurrentValue(String detail){

        if(detail=="first_name")
            return getUserDetails().get("firstName").toString();
        else if(detail=="last_name")
            return getUserDetails().get("lastName").toString();
        else if(detail=="email_address")
            return getUserDetails().get("email").toString();

        return "";
    }

    public Map getUserDetails(){

        Map<String,String> userDetails = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String getUserDetailsQuery = "SELECT * FROM "+USER_INFO_TABLE;
        Cursor cursor = db.rawQuery(getUserDetailsQuery,null);

        if(cursor.moveToFirst()){
            userDetails.put("firstName",cursor.getString(1));
            userDetails.put("lastName",cursor.getString(2));
            userDetails.put("email",cursor.getString(3));
            userDetails.put("pin",cursor.getString(4));
            userDetails.put("emergencyPhone",cursor.getString(5));
            userDetails.put("emergencyEmail",cursor.getString(6));
        }
        cursor.close();
        db.close();
        return userDetails;
    }

    public boolean didUserRegister(){
        boolean result = false;
        SQLiteDatabase db = this.getReadableDatabase();

        String getUserDetailsQuery = "SELECT * FROM "+USER_INFO_TABLE;
        Cursor cursor = db.rawQuery(getUserDetailsQuery,null);
        if(cursor.moveToFirst())
            result = true;
        return result;
    }

    public boolean verifyPassword(String pin){
        boolean isValidPin = false;
        Map m = getUserDetails();
        System.out.println(m);
        System.out.println(MD5.getHashedPassword(pin));
        if(m.get("pin").equals(MD5.getHashedPassword(pin)))
            isValidPin = true;
        return isValidPin;
    }

    public String getEmergencyPhone(){
        return getUserDetails().get("emergencyPhone").toString();
    }

    boolean result = false;
    public boolean registerUser(final UserDetails user){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues userDetailsCv = new ContentValues();
        userDetailsCv.put(COLUMN_USER_ID,1);
        userDetailsCv.put(COLUMN_FIRST_NAME,user.getFirstName());
        userDetailsCv.put(COLUMN_LAST_NAME,user.getLastName());
        userDetailsCv.put(COLUMN_EMAIL,user.getEmailID());
        userDetailsCv.put(COLUMN_PIN,user.getHashedPin());
        userDetailsCv.put(COLUMN_EMERGENCY_PHONE,user.getEmergencyPhone());
        userDetailsCv.put(COLUMN_EMERGENCY_EMAIL,user.getEmergencyEmailID());

        long isSuccess = db.insert(USER_INFO_TABLE,null, userDetailsCv);

        if(isSuccess!=-1)
            result = true;

        db.close();
    return result;
    }

    public boolean changeDetails(String detail, String newValue){

        ContentValues contentValues = new ContentValues();
        SQLiteDatabase db = this.getWritableDatabase();
        long isupdateSuccess;
        boolean result = false;

        if(detail == "first_name"){
            contentValues.put(COLUMN_FIRST_NAME,newValue);
        }
        else if(detail == "last_name"){
            contentValues.put(COLUMN_LAST_NAME,newValue);
        }
        else if(detail == "email_address"){
            contentValues.put(COLUMN_EMAIL,newValue);
        }
        isupdateSuccess = db.update(USER_INFO_TABLE,contentValues,COLUMN_USER_ID+"=1",null);
        if(isupdateSuccess==1)
            result = true;
        return result;
    }

    public boolean changePassword(String newPin){
        ContentValues contentValues = new ContentValues();
        SQLiteDatabase db = this.getWritableDatabase();
        long isupdateSuccess;
        boolean result = false;

        contentValues.put(COLUMN_PIN,MD5.getHashedPassword(newPin));

        isupdateSuccess = db.update(USER_INFO_TABLE,contentValues,COLUMN_USER_ID+"=1",null);
        if(isupdateSuccess==1)
            result = true;
        return result;
    }

}
